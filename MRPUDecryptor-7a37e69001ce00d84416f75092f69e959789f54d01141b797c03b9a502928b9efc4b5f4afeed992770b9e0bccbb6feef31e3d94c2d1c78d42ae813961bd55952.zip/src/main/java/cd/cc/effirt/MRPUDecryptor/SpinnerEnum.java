package cd.cc.effirt.MRPUDecryptor;

public enum SpinnerEnum {
    UNICODE("unicode", new String[]{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}, 200),
    ASCII("ascii", new String[]{"|", "/", "-", "\\"}, 500),
    NONE("none", new String[0], 1000);

    private final String label;
    private final String[] frames;
    private final long intervalMs;

    SpinnerEnum(String label, String[] frames, long intervalMs) {
        this.label = label;
        this.frames = frames;
        this.intervalMs = intervalMs;
    }

    public String[] frames() {
        return frames;
    }

    public long intervalMs() {
        return intervalMs;
    }

    @Override
    public String toString() {
        return label;
    }
}