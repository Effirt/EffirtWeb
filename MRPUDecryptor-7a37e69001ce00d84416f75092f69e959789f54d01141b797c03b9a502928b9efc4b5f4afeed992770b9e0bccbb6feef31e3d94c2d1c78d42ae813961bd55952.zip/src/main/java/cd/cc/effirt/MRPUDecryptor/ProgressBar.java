package cd.cc.effirt.MRPUDecryptor;

import java.util.concurrent.atomic.AtomicLong;

public class ProgressBar {

    private static final int WIDTH = 20;
    private static final long REFRESH_MS = 250L;

    private final Thread thread;

    private volatile String customText = "";
    private volatile long done;
    private volatile long todo;
    private volatile boolean finished;

    private final AtomicLong version = new AtomicLong();

    public ProgressBar(ProgressBarEnum progressBar) {
        if (progressBar == null || progressBar == ProgressBarEnum.NONE) {
            this.thread = null;
            return;
        }
        this.thread = createThread(progressBar);
        this.thread.start();
    }

    private Thread createThread(ProgressBarEnum progressBar) {
        final String doneChar = progressBar.getProgressBarCharDone();
        final String todoChar = progressBar.getProgressBarChar();

        Thread t = new Thread(() -> {
            long seenVersion = -1L;
            boolean partialLine = false;

            try {
                while (!finished) {
                    long d = done;
                    long tt = todo;
                    long v = version.get();
                    if (v != seenVersion) {
                        seenVersion = v;
                        if (tt > 0) {
                            IO.print(format(d, tt, customText, doneChar, todoChar) + '\r');
                            partialLine = true;

                            if (d >= tt) {
                                IO.println();
                                partialLine = false;
                                return;
                            }
                        }
                    }
                    Thread.sleep(REFRESH_MS);
                }
            } catch (InterruptedException _) {
                Thread.currentThread().interrupt();
            } finally {
                long v = version.get();
                if (v != seenVersion && todo > 0) {
                    IO.print(format(done, todo, customText, doneChar, todoChar) + '\r');
                    partialLine = true;
                }
                if (partialLine) IO.println();
            }
        }, "progressBarThread");
        t.setDaemon(true);
        return t;
    }

    private static String format(long done, long todo, String customText, String doneChar, String todoChar) {
        long filledL = done * (long) WIDTH / todo;
        int filled = (int) Math.max(0L, Math.min(WIDTH, filledL));
        long pct = done * 100L / todo;

        StringBuilder sb = new StringBuilder(WIDTH + 32);
        sb.append(pct).append("% ");
        sb.append(doneChar.repeat(filled));
        sb.append(todoChar.repeat(WIDTH - filled));
        if (customText != null && !customText.isEmpty()) {
            sb.append(' ').append(customText);
        }
        return sb.toString();
    }

    public void setCustomText(String text) {
        this.customText = (text == null) ? "" : text;
        version.incrementAndGet();
    }

    public void setDone(long done) {
        this.done = done;
        version.incrementAndGet();
    }

    public void setTodo(long todo) {
        this.todo = todo;
        version.incrementAndGet();
    }

    public void finish() {
        finished = true;
        if (thread != null) {
            thread.interrupt();
            try { thread.join(REFRESH_MS + 200L); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    /*
    public static void progress(long done, long todo, String customText, ProgressBarEnum progressBar) {
        if (progressBar == ProgressBarEnum.NONE) return;
        if (todo <= 0) return;

        String doneChar = progressBar.getProgressBarCharDone();
        String todoChar = progressBar.getProgressBarChar();

        final int width = 20;
        int filled = (int) (done * (long) width / todo);
        filled = Math.max(0, Math.min(width, filled));

        long pct = done * 100 / todo;

        String sb = pct + "% " +
                String.valueOf(doneChar).repeat(filled) +
                String.valueOf(todoChar).repeat(width - filled) +
                " " + customText;

        if (done >= todo) {
            IO.print(sb + "\r");
            IO.println();
        } else {
            IO.print(sb + "\r");
        }
    }
     */
}
