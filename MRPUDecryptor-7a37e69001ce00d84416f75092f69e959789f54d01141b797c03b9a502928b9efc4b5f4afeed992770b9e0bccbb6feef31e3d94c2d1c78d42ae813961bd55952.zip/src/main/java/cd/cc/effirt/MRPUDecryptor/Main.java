package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.MRPUDecryptor.error.MRPUSafeError;
import cd.cc.effirt.DevKit.Log;
import cd.cc.effirt.MRPUDecryptor.exception.InitializeFailedException;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.nio.file.Path;
import java.time.Year;
import java.util.concurrent.Callable;

import static cd.cc.effirt.MRPUDecryptor.ExitCode.*;

@Command(name = "MRPU-Decryptor",
        mixinStandardHelpOptions = true,
        versionProvider = VersionProvider.class,
        exitCodeListHeading = "Exit Codes:%n",
        exitCodeList = {
                OK + ": Successful",
                USAGE + ": Invalid argument",
                INIT_FAILED + ": Initialization failed",
                DECRYPT_FAIL + ": Decryption failed",
                UNSAFE + ": masmeta.bin unsafe (Stored path has ../)"
        }
)
public class Main implements Callable<Integer> {

    @Option(names = {"-i", "--input"}, required = true, paramLabel = "<Path>",
            description = "Encrypted directory resources pack path")
    Path input;

    @Option(names = {"-o", "--output"}, paramLabel = "<Path>",
            description = "Decrypted directory resources output path")
    Path output;

    @Option(names = {"--no-banner"},
            description = "Disable banner")
    boolean noBanner;

    @Option(names = {"--skip-masked-file"},
            description = "Skip decrypt masked file")
    boolean skipMaskedFile;

    @Option(names = {"--debug"},
            description = "Enable debug")
    boolean debug;

    @Option(names = {"--spinner"}, defaultValue = "ascii", paramLabel = "<type>",
            description = "Spinner style (${COMPLETION-CANDIDATES})")
    SpinnerEnum spinnerStyleEnum;

    @Option(names = {"--terminal"}, defaultValue = "rich", paramLabel = "<mode>",
            description = "Terminal output mode (${COMPLETION-CANDIDATES})")
    TerminalModeEnum terminalModeEnum;

    @Option(names = {"--progress-bar"}, defaultValue = "none", paramLabel = "<mode>",
            description = "Progress bar mode (${COMPLETION-CANDIDATES})")
    ProgressBarEnum progressBar;

    static void main(String[] args) {
        CommandLine cl = new CommandLine(new Main());

        cl.setParameterExceptionHandler((e, _) -> {
            Log.error(e.getMessage());
            cl.usage(System.err);

            return USAGE;
        });

        System.exit(cl.execute(args));
    }

    @Override
    public Integer call() {
        if (!noBanner && terminalModeEnum != TerminalModeEnum.QUIET)
            banner();

        if (terminalModeEnum == TerminalModeEnum.QUIET) {
            Log.setEnableInfo(false);
        }

        if (debug) {
            Log.setEnableDebug(true);
        }

        Path output = (this.output != null)
                ? this.output
                : input.resolveSibling(input.getFileName() + "_MRPU-Decryptor");

        Log.info("Initializing...");
        try (Spinner _ = new Spinner(spinnerStyleEnum)) {
            Core.run(input, output, terminalModeEnum, skipMaskedFile, progressBar);
        } catch (InitializeFailedException e) {
            Log.error("Initialize failed: {}", e.getMessage());
            Log.debug("Initialize failed stack trace", e);
            return INIT_FAILED;
        } catch (MRPUSafeError e) {
            Log.error("masmeta.bin has unsafe: {}", e.getMessage());
            Log.debug("masmeta.bin has unsafe stack trace", e);
            return UNSAFE;
        } catch (Exception ex) {
            Log.error("Decryption failed", ex);
            return DECRYPT_FAIL;
        }
        return OK;
    }

    private static void banner() {
        IO.println("""
                  __  __ ___ ___ _   _   ___                       _          \s
                 |  \\/  | _ \\ _ \\ | | | |   \\ ___ __ _ _ _  _ _ __| |_ ___ _ _\s
                 | |\\/| |   /  _/ |_| | | |) / -_) _| '_| || | '_ \\  _/ _ \\ '_|
                 |_|  |_|_|_\\_|  \\___/  |___/\\___\\__|_|  \\_, | .__/\\__\\___/_| \s
                                                         |__/|_|              \s
                 MRPU Decryptor - Copyright (c) %s Effirt
                 """.formatted(
                        Year.now().getValue()
                )
        );
    }
}