package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.DevKit.Log;
import cd.cc.effirt.MRPUDecryptor.exception.MRPUEncryptedFileException;
import net.jpountz.xxhash.XXHashFactory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ParseBody {
    private static final int HEADER_LEN = 48;
    private static final long XXH64_SEED = 0L;

    public static ParsedRecord parseBody(byte[] masMeta, HeaderRecord header, boolean noMaskedFile) throws Exception {
        byte[] encBody = Arrays.copyOfRange(masMeta, HEADER_LEN, masMeta.length);

        long actual = XXHashFactory.safeInstance().hash64().hash(encBody, 0, encBody.length, XXH64_SEED);
        if (actual != header.bodyChecksum()) {
            Log.warn("Body checksum mismatch: Head={}, Real={}",
                    String.format("%016x", header.bodyChecksum()),
                    String.format("%016x", actual));
        }

        byte[] key = DeriveMetaKey.deriveMetaKey(header.packUuid());
        byte[] body = ZSTDDecompress.zstdDecompress(AESCTRDecrypt.AESCTRDecryptor(key, header.iv(), encBody));

        var files = new LinkedHashMap<String, EntryRecord>();
        var rootFiles = new LinkedHashSet<String>();
        Deque<String> dirs = new ArrayDeque<>();
        int pos = 0;

        while (pos < body.length) {
            int pkt = body[pos++] & 0xFF;
            switch (pkt) {
                case 0x10 -> {
                    int len = body[pos++] & 0xFF;
                    dirs.addLast(new String(body, pos, len, StandardCharsets.UTF_8));
                    pos += len;
                }
                case 0x11 -> {
                    if (dirs.isEmpty())
                        throw new MRPUEncryptedFileException("The directory stack is empty at EndDir");
                    dirs.removeLast();
                }
                case 0x20 -> {
                    var bb = ByteBuffer.wrap(body, pos, 16).order(ByteOrder.LITTLE_ENDIAN);
                    long unc = Integer.toUnsignedLong(bb.getInt());
                    long cmp = Integer.toUnsignedLong(bb.getInt());
                    long fid = bb.getLong();
                    pos += 16;

                    int nlen = body[pos++] & 0xFF;
                    String name = new String(body, pos, nlen, StandardCharsets.UTF_8);
                    pos += nlen;

                    var entry = new EntryRecord(name, unc, cmp, fid);

                    if (dirs.isEmpty()) {
                        rootFiles.add(name);
                    } else {
                        var parts = new ArrayList<>(dirs);
                        if (!parts.isEmpty() && ":#".equals(parts.getFirst())) {
                            parts.removeFirst();
                        }

                        if (parts.isEmpty()) {
                            if (!noMaskedFile) {
                                files.putIfAbsent("_MRPU-Decryptor/couldNotRevertPath/" + name, entry);
                            }
                        } else {
                            String full = String.join("/", parts) + "/" + name;
                            files.putIfAbsent(full, entry);
                        }
                    }
                }
                default -> throw new MRPUEncryptedFileException(
                        String.format("Unknown pack type: 0x%02x (Location %d)", pkt, pos - 1));
            }
        }
        return new ParsedRecord(files, rootFiles);
    }
}