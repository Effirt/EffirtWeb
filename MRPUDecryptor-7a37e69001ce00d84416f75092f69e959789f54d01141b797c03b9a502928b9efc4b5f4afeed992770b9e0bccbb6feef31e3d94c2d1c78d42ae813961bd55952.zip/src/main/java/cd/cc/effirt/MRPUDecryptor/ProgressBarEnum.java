package cd.cc.effirt.MRPUDecryptor;

public enum ProgressBarEnum {
    NONE("none", "", ""),
    ASCII("ascii", "#", "-"),
    UNICODE("unicode", "█", "▒");

    private final String progressBarName;
    private final String progressBarCharDone;
    private final String progressBarChar;

    ProgressBarEnum(String progressBarName, String progressBarCharDone, String progressBarChar) {
        this.progressBarName = progressBarName;
        this.progressBarCharDone = progressBarCharDone;
        this.progressBarChar = progressBarChar;
    }

    public String getProgressBarCharDone() {
        return progressBarCharDone;
    }

    public String getProgressBarChar() {
        return progressBarChar;
    }

    @Override
    public String toString() {
        return progressBarName;
    }
}
