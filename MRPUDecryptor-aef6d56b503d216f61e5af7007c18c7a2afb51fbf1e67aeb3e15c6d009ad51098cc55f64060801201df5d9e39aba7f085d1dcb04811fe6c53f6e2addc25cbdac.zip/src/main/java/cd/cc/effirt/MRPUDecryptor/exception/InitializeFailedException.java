package cd.cc.effirt.MRPUDecryptor.exception;

public class InitializeFailedException extends RuntimeException {

    public InitializeFailedException(String message,Throwable cause) {
        super(message,cause);
    }
}
