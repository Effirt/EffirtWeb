package cd.cc.effirt.MRPUDecryptor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public class DeriveFileKey {
    private static final long K_FILE_MSB = 0xDBA5533ABAC89847L;
    private static final long K_FILE_LSB = 0x959FF0C687777534L;

    public static byte[] deriveFileKey(UUID u, long fileId) {
        var bb = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN);
        bb.putLong(u.getMostSignificantBits() ^ fileId ^ K_FILE_MSB);
        bb.putLong(u.getLeastSignificantBits() ^ fileId ^ K_FILE_LSB);
        return bb.array();
    }
}
