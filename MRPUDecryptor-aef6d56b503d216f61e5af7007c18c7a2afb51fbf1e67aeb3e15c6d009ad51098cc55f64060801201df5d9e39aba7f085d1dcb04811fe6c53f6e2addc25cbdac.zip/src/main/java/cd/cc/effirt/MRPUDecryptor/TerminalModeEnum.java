package cd.cc.effirt.MRPUDecryptor;

public enum TerminalModeEnum {
    PLAIN("plain"),
    QUIET("quiet"),
    RICH("rich");

    private final String label;

    TerminalModeEnum(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
