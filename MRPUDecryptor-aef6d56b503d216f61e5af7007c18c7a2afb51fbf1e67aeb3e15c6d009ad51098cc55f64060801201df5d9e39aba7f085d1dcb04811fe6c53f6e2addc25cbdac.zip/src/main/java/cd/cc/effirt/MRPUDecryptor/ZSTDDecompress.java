package cd.cc.effirt.MRPUDecryptor;

import com.github.luben.zstd.ZstdInputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ZSTDDecompress {

    public static byte[] zstdDecompress(byte[] data) throws IOException {
        try (var in = new ZstdInputStream(new ByteArrayInputStream(data));
             var out = new ByteArrayOutputStream()) {
            in.transferTo(out);
            return out.toByteArray();
        }
    }
}
