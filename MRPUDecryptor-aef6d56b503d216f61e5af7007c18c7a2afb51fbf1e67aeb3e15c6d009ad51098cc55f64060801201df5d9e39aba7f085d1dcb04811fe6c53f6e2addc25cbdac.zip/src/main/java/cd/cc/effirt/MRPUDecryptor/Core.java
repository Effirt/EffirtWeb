package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.DevKit.Log;
import cd.cc.effirt.MRPUDecryptor.error.MRPUSafeError;
import cd.cc.effirt.MRPUDecryptor.exception.InitializeFailedException;
import cd.cc.effirt.MRPUDecryptor.exception.MRPUMetaException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class Core {

    public static void run(Path encrypted, Path decrypted, TerminalModeEnum terminalModeEnum) throws Exception {
        byte[] masMeta;
        try {
            masMeta = Files.readAllBytes(encrypted.resolve("masmeta.bin"));
        } catch (NoSuchFileException e) {
            throw new InitializeFailedException("File masmeta.bin not found in path '" + encrypted + "'", e);
        } catch (IOException e) {
            throw new MRPUMetaException("Failed to read masmeta.bin", e);
        }
        Files.createDirectories(decrypted);
        var header = ParseHeader.parseHeader(masMeta);
        Log.info("Pack UUID: {}", header.packUuid());

        var parsed = ParseBody.parseBody(masMeta, header);
        var entries = parsed.entries();
        Log.info("Found {} files in path {}",
                (entries.size() + parsed.rootFiles().size()), encrypted);

        long ok = 0, fail = 0, copyOk = 0;

        Log.info("Copying files...");
        for (var rootFile : parsed.rootFiles()) {
            try {
                var in = encrypted.resolve(rootFile);
                var out = safeResolve(decrypted, rootFile, "Root file has unsafe path");

                Log.debug("File copying: {}", rootFile);
                if (copyOk % 100 == 0 && terminalModeEnum == TerminalModeEnum.PLAIN)
                    Log.info("File copying: {}/{}",
                            copyOk, parsed.rootFiles().size());
                Files.createDirectories(out.getParent());
                Files.copy(in, out, StandardCopyOption.REPLACE_EXISTING);
                copyOk++;
            } catch (Exception e) {
                Log.error("Failed to copy file: {}", rootFile, e);
                fail++;
            }
        }

        if (copyOk > 0 && copyOk % 100 != 0 && terminalModeEnum == TerminalModeEnum.PLAIN)
            Log.info("File copying: {}/{}",
                    copyOk, parsed.rootFiles().size());

        Log.info("Decrypting files...");
        for (var e : entries.entrySet()) {
            var path = e.getKey();
            var entry = e.getValue();
            try {
                var plain = DecryptFile.decryptFile(encrypted, header.packUuid(), entry);
                var out = safeResolve(decrypted, path, "masmeta.bin has unsafe path");

                Log.debug("File decrypting: {}", path);
                if (ok % 100 == 0 && terminalModeEnum == TerminalModeEnum.PLAIN)
                    Log.info("File decrypting: {}/{}",
                            ok, (entries.size()));
                Files.createDirectories(out.getParent());
                Files.write(out, plain);
                ok++;
            } catch (Exception ex) {
                Log.error("Failed to decrypt file: {}", path, ex);
                fail++;
            }
        }

        if (ok > 0 && ok % 100 != 0 && terminalModeEnum == TerminalModeEnum.PLAIN)
            Log.info("File decrypting: {}/{}",
                    ok, (entries.size()));

        Log.info("Done. Copied {} files, Decrypted {} files, failed {} files. Decrypted path: {}",
                copyOk, ok, fail, decrypted);
    }

    private static Path safeResolve(Path base, String relative, String whatFor) throws MRPUSafeError {
        Path candidate = base.resolve(relative);
        Path normalizedBase = base.toAbsolutePath().normalize();
        Path normalized = candidate.toAbsolutePath().normalize();

        if (!normalized.startsWith(normalizedBase)) {
            throw new MRPUSafeError(whatFor + ": " + relative + " -> " + normalized);
        }
        return normalized;
    }
}