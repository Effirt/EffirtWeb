package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.MRPUDecryptor.exception.MRPUEncryptedFileException;
import net.jpountz.xxhash.XXHashFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.UUID;

public class DecryptFile {
    private static final long XXH64_SEED = 0L;

    public static byte[] decryptFile(Path root, UUID packUuid, EntryRecord entry) throws Exception {
        var bin = root.resolve("masbin")
                .resolve(String.format("%02x", entry.fileId() & 0xFF))
                .resolve(String.format("%016x", entry.fileId()) + ".bin");

        if (!Files.isRegularFile(bin))
            throw new MRPUEncryptedFileException("File missing: " + bin);

        byte[] raw = Files.readAllBytes(bin);
        if (raw.length < 16)
            throw new MRPUEncryptedFileException("File length lower than IV: " + bin);

        byte[] iv = Arrays.copyOfRange(raw, 0, 16);
        byte[] enc = Arrays.copyOfRange(raw, 16, raw.length);

        byte[] plain = ZSTDDecompress.zstdDecompress(
                AESCTRDecrypt.AESCTRDecryptor(DeriveFileKey.deriveFileKey(packUuid, entry.fileId()), iv, enc));

        long actualFid = XXHashFactory.safeInstance().hash64().hash(plain, 0, plain.length, XXH64_SEED);
        if (actualFid != entry.fileId())
            throw new MRPUEncryptedFileException(String.format("Content hash mismatch: Expected=%016x, Actual=%016x", entry.fileId(), actualFid));

        return plain;
    }
}
