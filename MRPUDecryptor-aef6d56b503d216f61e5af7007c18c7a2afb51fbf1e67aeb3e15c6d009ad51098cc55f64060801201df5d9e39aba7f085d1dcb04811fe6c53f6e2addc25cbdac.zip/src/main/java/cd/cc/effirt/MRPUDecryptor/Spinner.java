package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.DevKit.Log;

public class Spinner implements AutoCloseable {
    private final Thread thread;

    public Spinner(SpinnerEnum spinnerEnum, TerminalModeEnum terminalModeEnum) {
        if (spinnerEnum == SpinnerEnum.NONE
                || terminalModeEnum == TerminalModeEnum.PLAIN
                || terminalModeEnum == TerminalModeEnum.QUIET
        ) {
            this.thread = null;
            return;
        }
        this.thread = createThread(spinnerEnum);
        this.thread.start();
    }

    private static Thread createThread(SpinnerEnum style) {
        Thread spinner = new Thread(() -> {
            char[] symbols = style.frames();
            long interval = style.intervalMs();
            int index = 0;
            while (!Thread.currentThread().isInterrupted()) {
                IO.print(symbols[index] + "\r");
                index = (index + 1) % symbols.length;
                try {
                    Thread.sleep(interval);
                } catch (InterruptedException _) {
                    IO.print(" ".repeat(80) + "\r");
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "spinnerThread");
        spinner.setDaemon(true);
        return spinner;
    }

    @Override
    public void close() {
        if (thread == null) {
            return;
        }
        thread.interrupt();
        try {
            thread.join(5555);
        } catch (InterruptedException e) {
            Log.error("Spinner stop failed", e);
            Thread.currentThread().interrupt();
        }
    }
}