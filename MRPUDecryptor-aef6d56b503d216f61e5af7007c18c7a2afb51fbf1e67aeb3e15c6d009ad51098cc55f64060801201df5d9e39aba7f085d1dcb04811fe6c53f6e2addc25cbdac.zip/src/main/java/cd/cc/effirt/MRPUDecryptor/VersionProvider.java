package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.DevKit.Log;
import picocli.CommandLine;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class VersionProvider implements CommandLine.IVersionProvider {
    private static final String FALLBACK = "Dev";
    private static final String VERSION_RESOURCE = "/META-INF/MRPUDecryptor.version";
    private static final String VERSION = load();

    private static String load() {
        try (InputStream is = VersionProvider.class.getResourceAsStream(VERSION_RESOURCE)) {
            if (is == null) return FALLBACK;
            Properties p = new Properties();
            Log.debug("Reading version: '{}'...", VERSION_RESOURCE);
            p.load(is);
            String s = p.getProperty("version", FALLBACK).trim();
            Log.debug("Version: {}", s);
            return s;
        } catch (IOException e) {
            Log.debug("Failed to read version", e);
            return FALLBACK;
        }
    }

    @Override
    public String[] getVersion() {
        return new String[]{VERSION};
    }
}
