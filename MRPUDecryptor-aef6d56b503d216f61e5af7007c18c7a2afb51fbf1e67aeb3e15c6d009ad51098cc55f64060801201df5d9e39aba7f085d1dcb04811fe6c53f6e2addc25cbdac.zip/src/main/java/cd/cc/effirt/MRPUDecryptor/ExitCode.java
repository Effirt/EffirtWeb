package cd.cc.effirt.MRPUDecryptor;

public class ExitCode {
    public static final int OK = 0;
    public static final int USAGE = 2;
    public static final int INIT_FAILED = 3;
    public static final int DECRYPT_FAIL = 4;
    public static final int UNSAFE = 5;
}