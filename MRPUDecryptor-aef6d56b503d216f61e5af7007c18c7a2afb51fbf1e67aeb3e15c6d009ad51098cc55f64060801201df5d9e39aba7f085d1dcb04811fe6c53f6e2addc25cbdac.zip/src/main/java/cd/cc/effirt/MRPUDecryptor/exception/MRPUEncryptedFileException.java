package cd.cc.effirt.MRPUDecryptor.exception;

public class MRPUEncryptedFileException extends RuntimeException {
    public MRPUEncryptedFileException(String message) {
        super(message);
    }
}
