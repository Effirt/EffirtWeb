package cd.cc.effirt.MRPUDecryptor;

public record EntryRecord(String name, long uncompressedSize, long compressedSize, long fileId) {
}
