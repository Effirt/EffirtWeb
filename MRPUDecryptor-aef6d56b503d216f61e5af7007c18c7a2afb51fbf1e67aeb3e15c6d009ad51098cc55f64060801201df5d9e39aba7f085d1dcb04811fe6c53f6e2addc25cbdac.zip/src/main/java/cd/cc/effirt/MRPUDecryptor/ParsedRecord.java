package cd.cc.effirt.MRPUDecryptor;

import java.util.Map;
import java.util.Set;

public record ParsedRecord(Map<String, EntryRecord> entries, Set<String> rootFiles) {
}
