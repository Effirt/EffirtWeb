package cd.cc.effirt.MRPUDecryptor;

import java.util.UUID;

public record HeaderRecord(long bodyChecksum, UUID packUuid, byte[] iv) {
}
