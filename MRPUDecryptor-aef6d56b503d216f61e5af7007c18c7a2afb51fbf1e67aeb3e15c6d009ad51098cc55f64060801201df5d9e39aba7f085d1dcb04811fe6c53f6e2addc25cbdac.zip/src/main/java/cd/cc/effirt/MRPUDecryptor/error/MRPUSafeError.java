package cd.cc.effirt.MRPUDecryptor.error;

public class MRPUSafeError extends Error {
    public MRPUSafeError(String message) {
        super(message);
    }
}
