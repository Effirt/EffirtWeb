package cd.cc.effirt.MRPUDecryptor;

import cd.cc.effirt.MRPUDecryptor.exception.MRPUMetaException;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public class ParseHeader {
    private static final byte[] MAGIC = {'M', 'A', 'S'};
    private static final int HEADER_LEN = 48;
    private static final int VERSION = 0;

    public static HeaderRecord parseHeader(byte[] blob) {
        if (blob.length < HEADER_LEN)
            throw new MRPUMetaException("masmeta.bin too short: " + blob.length);
        if (blob[0] != MAGIC[0] || blob[1] != MAGIC[1] || blob[2] != MAGIC[2])
            throw new MRPUMetaException("masmeta.bin Magic error");
        if (blob[3] != VERSION)
            throw new MRPUMetaException("No supported MRPUDecryptor.version: " + blob[3]);

        var le = ByteBuffer.wrap(blob).order(ByteOrder.LITTLE_ENDIAN);
        var be = ByteBuffer.wrap(blob).order(ByteOrder.BIG_ENDIAN);

        le.position(4);
        long checksum = le.getLong();

        be.position(16);
        var uuid = new UUID(be.getLong(), be.getLong());

        le.position(32);
        byte[] iv = new byte[16];
        le.get(iv);

        return new HeaderRecord(checksum, uuid, iv);
    }
}
