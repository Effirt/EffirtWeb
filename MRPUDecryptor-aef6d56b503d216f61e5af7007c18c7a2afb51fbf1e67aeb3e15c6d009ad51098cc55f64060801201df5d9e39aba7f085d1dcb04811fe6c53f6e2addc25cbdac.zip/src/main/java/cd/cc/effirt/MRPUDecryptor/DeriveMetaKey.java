package cd.cc.effirt.MRPUDecryptor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public class DeriveMetaKey {
    private static final long K_META_MSB = 0x3467D6039AD2217FL;
    private static final long K_META_LSB = 0xB04FF4FEEB3E458DL;

    public static byte[] deriveMetaKey(UUID u) {
        var bb = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN);
        bb.putLong(u.getMostSignificantBits() ^ K_META_MSB);
        bb.putLong(u.getLeastSignificantBits() ^ K_META_LSB);
        return bb.array();
    }
}
