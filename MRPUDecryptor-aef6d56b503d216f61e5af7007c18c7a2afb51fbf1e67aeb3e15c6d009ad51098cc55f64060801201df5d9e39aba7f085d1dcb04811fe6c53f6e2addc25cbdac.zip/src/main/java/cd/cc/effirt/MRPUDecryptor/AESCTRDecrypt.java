package cd.cc.effirt.MRPUDecryptor;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESCTRDecrypt {

    public static byte[] AESCTRDecryptor(byte[] key, byte[] iv, byte[] data) throws Exception {
        var c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c.doFinal(data);
    }
}
