package cd.cc.effirt.MRPUDecryptor.exception;

public class MRPUMetaException extends RuntimeException {
    public MRPUMetaException(String message) {
        super(message);
    }

    public MRPUMetaException(String message, Throwable cause) {
        super(message, cause);
    }
}
