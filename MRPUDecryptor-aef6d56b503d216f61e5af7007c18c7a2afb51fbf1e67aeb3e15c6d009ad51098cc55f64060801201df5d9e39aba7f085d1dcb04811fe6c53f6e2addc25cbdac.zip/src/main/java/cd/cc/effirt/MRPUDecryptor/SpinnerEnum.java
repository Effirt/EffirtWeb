package cd.cc.effirt.MRPUDecryptor;

public enum SpinnerEnum {
    BRAILLE("braille", new char[]{'⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'}, 100),
    BRAILLE_DOTS("braille-dots", new char[]{'⣷', '⣯', '⣟', '⡿', '⢿', '⣻', '⣽', '⣾'}, 100),
    ASCII("ascii", new char[]{'|', '/', '-', '\\'}, 500),
    BLOCK("block", new char[]{'▖', '▘', '▝', '▗'}, 500),
    CIRCLE_HALVES("circle-halves", new char[]{'◐', '◓', '◑', '◒'}, 500),
    NONE("none", new char[0], 1000);

    private final String label;
    private final char[] frames;
    private final long intervalMs;

    SpinnerEnum(String label, char[] frames, long intervalMs) {
        this.label = label;
        this.frames = frames;
        this.intervalMs = intervalMs;
    }

    public char[] frames() {
        return frames;
    }

    public long intervalMs() {
        return intervalMs;
    }

    @Override
    public String toString() {
        return label;
    }
}